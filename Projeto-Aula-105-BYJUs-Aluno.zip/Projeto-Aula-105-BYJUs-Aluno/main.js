
//https://makitweb.com/how-to-capture-picture-from-webcam-with-webcam-js/
var camera = document.getElementById("camera");

//Código copiado da página da API
//Ajustar a altura e largura
Webcam.set({
  width:350,
  height:300,
  image_format : 'png',
  png_quality:90
});
Webcam.attach( '#camera' );

//Código para capturar a imagem   
function takeSnapshot()
{
    //Acionar uma função da API e solicitar acionamento da 
    //pré-visualização (data_uri) da imagem após a captura.
    Webcam.snap(function(data_uri) {
      //Atualizando o HTML para exibir a imagem
      document.getElementById("result").innerHTML = '<img src="'+data_uri+'" id="captured_image"/>';
    });
}


//BIBLIOTECA ML5

